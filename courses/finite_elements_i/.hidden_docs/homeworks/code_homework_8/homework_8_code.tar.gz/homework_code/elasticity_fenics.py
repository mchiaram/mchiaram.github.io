## @author CEE 513 @ Princeton University
#  @date 12/1/2017
#  @brief Solving 2-D elasticity problem in FEniCS
#	and performing convergence studies.

from __future__ import print_function
from fenics import *
import sympy as sp
import numpy as np
import matplotlib.pyplot as plt

if __name__ == "__main__":

	# Define the geometry of the beam
	length = 1.0 # along x-axis
	depth = 0.1 # along y-axis

	# Number of devisions along x
	ndiv_x = 100
	# Number of devisions along y
	ndiv_y = 10

	# space dim, currently only 2-D
	space_dim = 2

	# Define the mesh in 2-D
	mesh = RectangleMesh(Point(0.0,0.0), Point(length, depth), ndiv_x, ndiv_y, "crossed")
	
	# Create the function space of 
	poly_order = 1
	# Since we need to create a vector valued finite element space,
	# we use VectorFunctionSpace
	V = VectorFunctionSpace(mesh, 'Lagrange', poly_order, dim = space_dim)

	# Define the lame parameters
	lmbda = 10.0
	mu = 1.0

	# Define the constitutive relation:
	# Define strain
	def eps(u):
		return sym(grad(u))

	# Define stress
	def sigma(u):
		eps_u = eps(u)
		return lmbda*tr(eps_u)*Identity(space_dim)+2.0*mu*eps_u

	# Define boundary conditions
	# The problem has Dirichlet boundary on the left edge and
	# Neumann on the rest

	# Define the dirichlet boundary
	# Left edge
	class dirichlet_boundary(SubDomain):
		def inside(self, x, on_boundary):
			return on_boundary and abs(x[0])< DOLFIN_EPS

	# Define the neumann boundaries
	# Top edge
	class neumann_boundary_top(SubDomain):
		def inside(self, x, on_boundary):
			return on_boundary and abs( x[1] - depth ) < DOLFIN_EPS

	# Bottom edge
	class neumann_boundary_bottom(SubDomain):
		def inside(self, x, on_boundary):
			return on_boundary and abs( x[1]) < DOLFIN_EPS

	# Right edge
	class neumann_boundary_right(SubDomain):
		def inside(self, x, on_boundary):
			return on_boundary and abs( x[0] - length ) < DOLFIN_EPS


	# Define the boundary measure (effectively a way to 
	# distinguish between Neumann and Dirichlet)
	boundaries = FacetFunction("size_t", mesh)
	dirichlet_boundary().mark(boundaries,1)
	neumann_boundary_top().mark(boundaries,2)
	neumann_boundary_right().mark(boundaries,3)
	neumann_boundary_bottom().mark(boundaries,4)
	ds = Measure("ds", subdomain_data=boundaries)

	# Define the analaytical solution
	# ue = sin(x)*y*\ee_1 + (-x^2+x)*\ee_2
	ue = Expression(('sin(x[0])*x[1]','-x[0]*x[0]+x[0]'),  degree=4)

	# Define the dirichlet boundary conditions
	# Specify the values of function at the boundary
	bc = DirichletBC(V, ue, dirichlet_boundary())

	# Define the trial and test function
	u = TrialFunction(V)
	v = TestFunction(V)

	# Define the forcing function

	# Define the bilinear form
	a = inner(sigma(u), grad(v))*dx

	# Define the forcing terms
	# Calculated using \nabla\cdot(\sigma) = f
	f = Expression(('-sin(x[0])*x[1]*(lmbda+2.0*mu)',\
			'<fill here>'),mu = mu, lmbda = lmbda, degree = 7 ) #<-- fill here

	# Define the traction terms:
	# The traction forces are computed using \sigma \cdot \nb = \tb
	# These are the Neumann BC Values
	traction_top = #<-- fill here
	traction_right = Expression(('(lmbda+2.0*mu)*(cos(x[0]))*x[1]',\
			'mu*(1.0-2.0*x[0]+sin(x[0]))'), lmbda=lmbda, mu=mu, degree=7) 
	traction_bottom = Expression(('-mu*(1.0-2.0*x[0]+sin(x[0]))',\
			'-lmbda*(cos(x[0]))*x[1]'), lmbda=lmbda, mu = mu, degree = 7)

	# Add the traction and the forcing terms
	F = -dot(f, v)*dx + <fill here> + \
			dot(traction_right, v)*ds(3) + dot(traction_bottom, v)*ds(4) #<-- fill here

	# Compute solution
	uh = Function(V)
	solve(a == F, uh, bc)

	ue = project(ue, V)
	
	# Compute error in L2 norm
	error_L2 = errornorm(ue, uh, 'L2')
	uh.rename('displacement', 'displacement')

	# Save the solution to be viewed in paraview
	file = XDMFFile("solution.xdmf")
	file.write(uh)
