from assembly import *
from lagrange_polynomials import *
import subdivide_quad_mesh
import subdivide_tri_mesh 
from apply_bc import *
from plotting import *
from errors import *
