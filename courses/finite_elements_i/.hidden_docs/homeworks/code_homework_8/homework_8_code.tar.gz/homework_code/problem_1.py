import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.tri as tri
import random
import numpy as np
import numpy.linalg as la 
from utils import lagrange_basis, d_lagrange_basis
import triangular_element


## @brief a starter code for part 2
def part_3(element):

	# Make data the grid over which computing 
	# the values of the shape function 
	xs = np.linspace(0, 1., 20)
	X, Y = np.meshgrid(xs, xs)

	C = np.array( filter(lambda x: x[0] <= -x[1] + 1.  , np.c_[ X.flatten(), Y.flatten() ] ) )
	x,y = C[:,0], C[:,1] 

	# Create the Triangulation just for plotting
	triang = tri.Triangulation(x, y)

	# Compute the value of the base function 
	for base_index in range( element.num_dofs ):
			
		# Initialize the value of the basis function
		z = np.zeros(len(x))	
			
		# Loop over all points
		for idx,crd in enumerate(np.c_[x,y]): 
			z[idx] = element. #<-- fill here
	
		# Initialize the figure
		fig = plt.figure()
		ax = fig.gca(projection='3d')
		
		# Plot the surface
		surf = ax.plot_trisurf(triang, z)

		# Format and save the figure
		plt.xlabel(r'$\xi^1$')
		plt.ylabel(r'$\xi^2$')
		ax.set_xticks( np.linspace(0,1,3) )
		ax.set_yticks( np.linspace(0,1,3) )
		ax.set_zticks( np.linspace(-0.5,1,4) )
		ax.set_zlim([-0.5,1])
		plt.title(r'Base function of index i = %i'%base_index)
		plt.savefig('figures/base_function_%i.pdf'%base_index)
		plt.close('all')


def part_4(element):

	# Create a list of sample points in the parametric domain
	xs = np.linspace(0, 1., 50)
	X, Y = np.meshgrid(xs, xs)

	X = np.array( filter(lambda x: x[0] <= -x[1] + 1.  , np.c_[ X.flatten(), Y.flatten() ] ) )

	# Map the points in the physical domain before 
	# interpolating the edge nodes quadratically
	Y = X*0
	for i,x in enumerate(X):
		Y[i] = element.get_map( x )
	plt.scatter( Y[:,0] , Y[:,1], c='orange' )

	# Set the value of all nodes
	Xe = np.array([  ]) # <-- fill here
	
	element.set_interior_nodes_coordinates(  ) # <- fill here
	plt.plot( element.nodes_crds_phys[:,0],  element.nodes_crds_phys[:,1], 'ro' )

	# Map the parametric points again to the 
	# physical domain using quadratic interpolation
	Y *= 0
	for i,x in enumerate(X):
		Y[i] = element.get_map( x )
	plt.scatter( Y[:,0] , Y[:,1], c='black' )
	plt.show()


def part_5(element):

	# Create a list of sample points in the parametric domain
	xs = np.linspace(0, 1., 50)
	X, Y = np.meshgrid(xs, xs)

	X = np.array( filter(lambda x: x[0] <= -x[1] + 1.  , np.c_[ X.flatten(), Y.flatten() ] ) )

	# Map the parametric points again to the 
	# physical domain using quadratic interpolation
	Y = X*0
	J = np.zeros( len(Y) )
	for i,x in enumerate(X):
		Y[i] = # <-- fill me here
		
		J[i] = # <-- fill me here 
	
	# Plot it
	plt.scatter( Y[:,0] , Y[:,1], c=J )
	plt.colorbar()
	plt.show()

def part_6(element):

	# Get the quadrature rule 
	q_points, q_weights = element.get_quadrature(2)

	# Initialize the value of the area 
	A = 0

	# Loop over all quadrature points
	for i in range(len(q_weights)):

		# Get the jacobian at the quadrature point
		jacobian = # <-- fill me here

		# Add the contribution 
		A += jacobian*q_weights[i] 

	print 'The value of the area is %.2f'%A


if __name__ == "__main__":

	# Define the order of the polynomial interpolant
	poly_order = 2

	# Define edge lenght of the triangle
	w = 2.

	# Create the mesh with a single element 
	coordinates = np.array([ (-w,0), (w,0), (0,w) ])
	
	# Connectivity 
	connectivity = np.array([[0,1,2]])

	# Construct an element  
	element_index = 0
	my_element = triangular_element.element( )  # <-- fill me here

	################
	# Part 2 
	part_2(my_element)

	################
	# Part 4
	part_4(my_element)

	################
	# Part 5
	part_5(my_element)

	################
	# Part 6
	part_6(my_element)



