"""
Created by Maurizio Chiaramonte 
	  
Copyright (c) 2017 Maurizio Chiaramonte

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.
"""

import numpy as np
import copy
import itertools 
from utils import lagrange_basis, d_lagrange_basis


## @brief the base functions defined over the unit two-dimensional
#  simplex as. It uses barycentric coordinates for the construction
#  @param[in] poly_order the polynmomial order of the interpolant 
#  @param[in] base_index the base order labeled as shown in the
#   graph depicted below. The numbering along the edges grown in 
#  the counterclockwise direction.
#  @param[in] the coordinate of where to evaluate the base function
#   
#   2
#  |  \
#  5 - 4
#  |   | \
#  3 - 6 - 1
class barycentric_basis_triangle: 
	
	def __init__(self, poly_order ):

		# The polynomial order 
		self.poly_order = poly_order 

		# The number of degrees of freedom
		self.num_dofs =  ( poly_order + 1)*(poly_order + 2 )/2

		# The number of vertex dof 
		self.vertex_dof = 3

		# The numberof edge dof 
		self.edge_dof = poly_order - 1

		# The number of interior dof 
		self.interior_dof = (poly_order - 1)*(poly_order - 2 )/2

		# Construct the position of the degrees of freedom 
		self.index = [] 
		for j in range( poly_order + 1 ):
			for i in range( poly_order + 1 - j ):
				self.index.append( (i,j, poly_order - i - j) )			

		self.index = np.array( self.index, dtype=[('i',int),('j',int),('k',int)] )
		
		# Here we are simply sorting the degrees of freedom to match the 
		# above numbering schem
		
		# Sort first vertex indeces 
		idx = np.argsort( map( lambda x: max(x) , self.index ) )[::-1]
		self.index = self.index[idx] 

		# Sort vertex indeces by barycentric coordinates 
		self.index[:self.vertex_dof] = \
				np.sort( self.index[:self.vertex_dof], order=('i','j','k') )[::-1]

		# Sort edge nodes 		
		if poly_order > 1:
			
			# The number of edgeds
			num_edges = 3 
			
			# The barycentric ``connectivity'' of each edge
			edge = [('k','j'),('i','k'),('j','i')]
			
			# Loop over each edge as sort its degrees of freedom
			for e in range(num_edges ) :
				self.index[self.vertex_dof+e*self.edge_dof:] = \
						np.sort( self.index[self.vertex_dof+e*self.edge_dof:], order=edge[e]  )
		
		# Create an array of barycentric coordinates corresponding to the degrees of freedom
		self.dof_nodes = np.array( map(lambda x: map(lambda y: y*1./poly_order,x) ,self.index) )

		# The one dimensional knot vector for a lagrange polynomial of order poly_order
		self.one_dim_knot = np.linspace(0, 1., self.poly_order  + 1 )
		
	## @brief returns the value of the Lagrange-type interpolation cf. Hughes App 3.1
	#  @param[in] index the index of base function
	#  @param[in] y the scalar value in the rage of [0,1] of the barycentric coordinate
	def t_value( self, index, y ):

		if index == 0 :
			return 1.

		# The nodes of the one dimensional polynomial 
		# over the parametric interval [0,1]
		param_one_dim = np.linspace(0, 1., index + 1 )

		return lagrange_basis(param_one_dim, index, index, y/self.one_dim_knot[index])

	## @brief returns the derivative of the Lagrange-type interpolation cf. Hughes App 3.1
	#  @param[in] index the index of base function
	#  @param[in] y the scalar value in the rage of [0,1] of the barycentric coordinate
	def dt_value( self, index, y ):

		if index == 0 :
			return 0

		# The nodes of the one dimensional polynomial 
		# over the parametric interval [0,1]
		param_one_dim = np.linspace(0, 1., index + 1 )

		return d_lagrange_basis(param_one_dim, index, index, y/self.one_dim_knot[index])*1./self.one_dim_knot[index]

	## @brief Gets the value of the basis function of index base_index evaluated at 
	#  a point in parametricspace with parametric coordinates x
	#  @param[in] base_index the index referring to the base to be evaluated
	#  @param[in] x the array of parametric coordinates values
	def get_val(self, base_index, x ):

		assert len( x ) == 2

		# Get the barycentric coordinates
		lam = np.append( x, 1. - np.sum( x  ) )

		return self.t_value( self.index[base_index][0],lam[0])*\
					 self.t_value( self.index[base_index][1],lam[1])*\
					 self.t_value( self.index[base_index][2],lam[2])
					 
	## @brief Gets the gradient of the basis function wrt parametric coordinates (not barycentric)
	#  of base base_index evaluated at a point in parametricspace with parametric coordinates x
	#  @param[in] base_index the index referring to the base to be evaluated
	#  @param[in] x the array of parametric coordinates values
	def get_dval( self, base_index,x ):

		assert len( x ) == 2

		# Get the barycentric coordinates
		lam = np.append( x, 1. - np.sum( x  ) )

		val_i = self.t_value( self.index[base_index][0],lam[0])
		val_j = self.t_value( self.index[base_index][1],lam[1])
		val_k = self.t_value( self.index[base_index][2],lam[2])

		return np.array([ self.dt_value( self.index[base_index][0],lam[0])*\
					 val_j*\
					 val_k +\
					 #
					 val_i*\
					 val_j*\
					 self.dt_value( self.index[base_index][2],lam[2])*(-1.),\
					 # 
					 val_i*\
					 self.dt_value( self.index[base_index][1],lam[1])*\
					 val_k +\
					 #
					 val_i*\
					 val_j*\
					 self.dt_value( self.index[base_index][2],lam[2])*(-1.) ])


