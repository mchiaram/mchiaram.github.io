## @author CEE 513 @ Princeton University
#  @date 12/1/2017
#  @brief Solving 2-D elasticity problem in FEniCS
#	and performing convergence studies.

from __future__ import print_function
from fenics import *
import sympy as sp
import numpy as np
import matplotlib.pyplot as plt

if __name__ == "__main__":

	# Display only errors
	set_log_level(ERROR)

	#---------------------------------------#
	# Define the problem parameters

	#Order of the polynomial interpolation
	order = 1

	# Space dimension in which we are solving the problem
	space_dim = 2

	# Create the mesh object
	mesh = Mesh()
	
	# We import the mesh
	XDMFFile("mesh/cook_mesh.xdmf").read(mesh)
	# The mesh uses the typical cook membrane geometry
	# ref. https://dealii.org/developer/doxygen/deal.II/code_gallery_Quasi_static_Finite_strain_Compressible_Elasticity.html
	
	# The material parameters
	nu = 0.3# poisson's ratio
	E = 1.0 # Young's modulus

	# Compute the lame` parameters
	mu = E/(2.0*(1.0+nu)) 
	lmbda = 2.0*mu*nu/(1.0-2.0*nu)


	# Define the function space
	# Define a vector element for displacement
	Ve_u = VectorElement("CG", mesh.ufl_cell(), order ,dim=space_dim)
	
	# Create the function space
	V = FunctionSpace(mesh, Ve_u)
	
	# Define the constitutive relation:
	# Define strain
	def strain(u):
		return sym(grad(u))

	# Define stress
	def sigma(u):
		eps = strain(u)
		return lmbda*tr(eps)*Identity(space_dim)+2.0*mu*eps

	# Define boundary conditions
	# The problem has Dirichlet boundary on the left edge and
	# Neumann on the rest

	# Define the boundary condition

	# First describe the dirichlet boundary
	# The left edge is clammed
	class dirichlet_boundary(SubDomain):
		def inside(self, x, on_boundary):
				 #<--- Fill here

	# Describe the Neumann boundary
	class neumann_boundary(SubDomain):
		def inside(self, x, on_boundary):
				 #<--- Fill here

	# Next we mark the boundaries for neumann bc
	boundaries = FacetFunction("size_t", mesh, 0)
	dirichlet = dirichlet_boundary()
	neumann = neumann_boundary()
	dirichlet.mark(boundaries, 0)
	neumann.mark(boundaries, 1)
	ds = Measure("ds", subdomain_data=boundaries)

	# We specify the dirichlet boundary on the displacement
	# V.sub(0) applies bc on the first function space, displacement
	# in our case.
	bc = DirichletBC(V, Constant((0.0,0.0)), dirichlet_boundary())

	# Specify the test and trial function
	u = TrialFunction(V)
	v = TestFunction(V)

	# Define the variational form
	a = inner(sigma(u),grad(v))*dx

	# Define the traction term
	t = Constant((0.0,1.0/16.))

	# Define the forcing functional
	F = #<---- Fill here

	# Compute the soultion
	uh = Function(V)

	solve(a==F, uh, bc)


	# Rename the functions
	uh.rename('displacement', 'displacement')

	# Save the file
	file_u = XDMFFile("standard_elasticity/displacement.xdmf")
	file_u.write(uh,0)