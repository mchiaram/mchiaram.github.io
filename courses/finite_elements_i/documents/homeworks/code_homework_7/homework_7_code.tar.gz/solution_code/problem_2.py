"""
Created by Maurizio Chiaramonte 
	  
Copyright (c) 2017 Maurizio Chiaramonte

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.
"""

import matplotlib 
import matplotlib.pyplot as plt
import numpy as np
import sympy as sp
import numpy.linalg

import quadrilateral_element
from element_operations.poisson import *
from utils import *


if __name__ == "__main__":

	# Define the order of the polynomial interpolant
	poly_order = 1

	# Define the half width of the domain
	w = 2.

	# Create the mesh of a square
	coordinates = np.array([ (-w,-w), (w,-w), (w,w), (-w,w) ])  

	# Connectivity 
	connectivity = np.array([[0,1,2,3]])

	# Refine a few times
	for i in range(4):
		coordinates, connectivity = subdivide_mesh( coordinates, connectivity )

	# Construct an array of element obejects 
	elements = []

	for e in range(len( connectivity ) ):
		elements.append( quadrilateral_element.element( e,\
				coordinates, connectivity, poly_order) )

	# Create an instance of the local to global map 
	# for the current mesh
	l2g = quadrilateral_element.local_to_global_map( poly_order, connectivity )

	# Print out 
	total_dofs =  l2g.get_total_dof()
	print( 'Total dofs : %i ' %( total_dofs  ))

	# Initialize stiffness matrix and force vector
	K = np.zeros( (total_dofs, total_dofs ) )
	F = np.zeros( total_dofs )

	# Initialize the element operation 
	f = lambda x: np.sin(x[0])
	poisson_problem = poisson( f )  

	print('Assemble system of equations')

	# Assemble global systems
	assemble_global(l2g, poisson_problem , elements, K, F )

	print('System of equations asembled')

	# Find all degrees of freedom on boundary
	boundary_dofs = l2g.get_boundary_dofs() 

	# Get the values of the boundary conditions
	boundary_vals = boundary_dofs*0 

	# Apply boundary conditions
	apply_bc(boundary_dofs, boundary_vals, K, F )

	# Solve
	u = np.linalg.solve( K, F ) 

	# Plot
	plot_contour_3d( coordinates, u )
	#plot_quad_mesh( coordinates, connectivity )
	plt.show()



	
