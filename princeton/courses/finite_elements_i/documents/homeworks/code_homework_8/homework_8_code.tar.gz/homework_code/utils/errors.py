"""
Created by Maurizio Chiaramonte 
	  
Copyright (c) 2017 Maurizio Chiaramonte

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.
"""

import numpy as np


# @param[in] local_to_global_map the local to global map
# @param[in] elements the array containing the element objects
# @param[in] uh the array of computed solution
# @param[in] ue the exact solution
# @return l2-norm of the error
def compute_l2_norm_error(local_to_global_map, elements, uh, ue ):
	
	l2_error = 0.

	for element in elements:
		# Get the element local degress of freedom
		num_dofs = element.get_num_dofs( )
	
		# Get the quadrature rule 
		gauss_points, gauss_weights = element.get_quadrature(2)
	
		# Integrate over the element
		for q in range(len(gauss_points)):
	
			# Get the jacobian at the quadrature point 
			jacobian = element.get_dmap( gauss_points[q], jacobian=True )
			
			# Get the image of the gauss point on the physical domain 
			x_g = element.get_map( gauss_points[q] )

			uh_g = 0.

			# Loop over all degree of freedoms
			for i in range(num_dofs):
				
				# Get the global index of the local i dof
				i_global = local_to_global_map.get_global_dof( element.element_index , i )
				
				# If we specified a source term
				uh_g += element.get_base_function_val(i,gauss_points[q])*uh[i_global]

			# Add contribution of intergral at gauss point
			l2_error += pow( ue( x_g ) - uh_g , 2 )*jacobian*gauss_weights[q]
	
	return np.sqrt(l2_error)


# @param[in] local_to_global_map the local to global map
# @param[in] elements the aray containing the element objects
# @param[in] uh the computed solution
# @param[in] ue the exact solution
# @param[in] due the derivative of the exact solution
# @return h1-norm of the error
def compute_h1_norm_error(local_to_global_map, elements, uh, ue, due):
	
	h1_error = 0.

	for element in elements:
		# Get the element local degress of freedom
		num_dofs = element.get_num_dofs( )
	
		# Get the quadrature rule 
		gauss_points, gauss_weights = element.get_quadrature()
	
		# Fill in the stiffness matrix
		for q in range(len(gauss_points)):
	
			# Get the jacobian at the quadrature point 
			jacobian = element.get_dmap( gauss_points[q], jacobian=True )
			
			# Get the image of the gauss point on the physical domain 
			x_g = element.get_map( gauss_points[q] )

			# Get the value of the gradient of all basis at the quadrature point

			uh_g = 0.
			duh_g = 0.

			# Loop over all degree of freedoms
			for i in range(num_dofs):
				# Get the global index of the local i dof
				i_global = local_to_global_map.get_global_dof( element.element_index , i )
				
				# If we specified a source term
				uh_g +=  element.get_base_function_val(i,gauss_points[q])*uh[i_global]
				duh_g += element.get_base_function_grad(i,gauss_points[q])*uh[i_global]

			# Add contribution of intergral at gauss point
			h1_error += pow( ue( x_g ) - uh_g , 2 )*jacobian*gauss_weights[q] + \
					np.dot((due( x_g ) - duh_g),  (due( x_g ) - duh_g))*jacobian*gauss_weights[q]
	
	return np.sqrt(h1_error)
