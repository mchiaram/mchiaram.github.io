"""
Created by Maurizio Chiaramonte 
	  
Copyright (c) 2017 Maurizio Chiaramonte

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.
"""


class triangle_quadrature:

	quadrature_points = [\
			# one point
			[ (0.33333333333333, 0.33333333333333) ],\
			# three point
			[ (0.6666666666666667e0,0.1666666666666667e0),\
				(0.1666666666666667e0,0.6666666666666667e0),\
				(0.1666666666666667e0,0.1666666666666667e0) ],\
			# four point 
			[ (0.33333333333333, 0.33333333333333),\
				(0.20000000000000, 0.20000000000000),\
				(0.20000000000000, 0.60000000000000),\
				(0.60000000000000, 0.20000000000000) ]
			]

	quadrature_weights = [ \
			[ 1./2 ],\
			[ 1./6,1./6,1./6  ],\
			[ -0.56250000000000/2,0.52083333333333/2,0.52083333333333/2,0.52083333333333/2]\
			]

	def get_quadrature( self, order ):
		
		assert order < len( self.quadrature_points ) 

		return self.quadrature_points[order], self.quadrature_weights[order]
