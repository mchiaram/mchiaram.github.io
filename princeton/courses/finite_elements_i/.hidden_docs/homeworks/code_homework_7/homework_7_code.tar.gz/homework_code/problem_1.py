"""
Created by Maurizio Chiaramonte 
	  
Copyright (c) 2017 Maurizio Chiaramonte

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.
"""

import os, sys
sys.path.append(os.getcwd()+'/../../')

import matplotlib 
import matplotlib.pyplot as plt
import numpy as np
import numpy.linalg

import quadrilateral_element
from mpl_toolkits.mplot3d import Axes3D


## @brief a starter code for part 2
def part_2(element):


	# Make data the grid over which computing 
	# the values of the shape function 
	xs = np.linspace(-1., 1., 20)
	X, Y = np.meshgrid(xs, xs)
	
	# Compute the value of the base function 
	for base_index in range( 9 ):
		Z = X*0
		for i in range( X.shape[0] ):
			for j in range( X.shape[1] ):
				y = np.array([X[i,j],Y[i,j]])
				Z[i,j] = element. # <- fill here

		# Plot the surface.
		fig = plt.figure()
		ax = fig.gca(projection='3d')

		surf = ax.plot_surface(X, Y, Z )

		# Format and save the figure
		plt.xlabel(r'$\xi^1$')
		plt.ylabel(r'$\xi^2$')
		ax.set_xticks( np.linspace(-1,1,3) )
		ax.set_yticks( np.linspace(-1,1,3) )
		ax.set_zticks( np.linspace(-0.5,1,4) )
		ax.set_zlim([-0.5,1])
		plt.title(r'Base function of index i = %i'%base_index)
		plt.savefig('../../figures/base_function_%i.pdf'%base_index)
		plt.close('all')

def part_4(element):

	# Create a list of sample points in the parametric domain
	xs = np.linspace(-1,1,100)
	X = np.meshgrid( xs, xs ) 
	X = np.c_[ X[0].flatten(), X[1].flatten() ]

	# Map the points in the physical domain before 
	# interpolating the edge nodes quadratically
	Y = X*0
	for i,x in enumerate(X):

		# Get the map of point x onto the physical domain
		Y[i] = element. #<- fill here
	
	plt.scatter( Y[:,0] , Y[:,1], c='orange' )

	# Create the coordinates of the curved physical element
	# corresponding to the degrees of freedom
	Xe = np.array([]) # <- fill here */ )

	# Set the value of all nodes
	my_element.  # <- fill here

	# Map the parametric points again to the 
	# physical domain using quadratic interpolation
	Y *= 0
	for i,x in enumerate(X):
		Y[i] = my_element. #<- fill here
	plt.scatter( Y[:,0] , Y[:,1], c='black' )
	plt.show()


def part_5(element):

	# Create a list of sample points in the parametric domain
	xs = np.linspace(-1,1,100)
	X = np.meshgrid( xs, xs ) 
	X = np.c_[ X[0].flatten(), X[1].flatten() ]

	# Map the parametric points again to the 
	# physical domain using quadratic interpolation
	Y = X*0
	J = np.zeros( len(Y) )
	for i,x in enumerate(X):

		# Get the map of point x onto the physical domain
		Y[i] = my_element. #<- fill here

		# Get the jacobian
		J[i] = my_element. #<- fill here 
	
	# Plot it
	plt.scatter( Y[:,0] , Y[:,1], c=J )
	plt.colorbar()
	plt.show()

def part_6(element):

	# Get the quadrature rule 
	q_points, q_weights = element.  # <- fill here
	
	# Initialize the value of the area 
	A = 0

	# Loop over all quadrature points
	for i in range(len(q_weights)):

		# Get the jacobian at the quadrature point
		jacobian = element. #<- fill here 

		# Add the contribution 
		A += #<- fill here 

	print 'The value of the area is %.2f'%A

if __name__ == "__main__":

	# Define the order of the polynomial interpolant
	poly_order = 2

	# Define the half width of the element
	w = 2.

	# Create the mesh with a single element of width 2w 
	# and centered at (3,3)
	coordinates = np.array([ (-w,-w), (w,-w), (w,w), (-w,w) ])
	
	# Connectivity 
	connectivity = np.array([[0,1,2,3]])

	# Construct an element  
	element_index = 0
	my_element = quadrilateral_element.element(  )  # <- fill here

	################
	# Part 2 
	part_2(my_element)

	################
	# Part 4
	part_4(my_element)

	################
	# Part 5
	part_5(my_element)

	################
	# Part 6
	part_6(my_element)







